#pragma once
#include "Core.h"
class Sample : public Core
{
};

