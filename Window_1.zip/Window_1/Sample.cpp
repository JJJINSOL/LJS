#include "Sample.h"
GAME_RUN(Window, 1024, 768);