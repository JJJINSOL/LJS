#include "Vector2.h"
Vector2:: Vector2()
{
	x = y = 0;
}
Vector2:: Vector2(float x, float y)
{
	this->x = x;
	this->y = y;
}
Vector2:: Vector2(const Vector2& v)
{
	x = v.x;
	y = v.y;
}
Vector2 Vector2:: operator + (const Vector2& v)
{
	this->x += v.x;
	this->y += v.y;
	return *this;
}
float Vector2:: Length(Vector2 a)
{
	float d = sqrt(pow((a.x), 2) + pow((a.y), 2));
	return d;
}
//����ȭ
Vector2 Vector2:: Normal(Vector2 a)
{
	Vector2 normal;
	
	float d = Length(a);

	normal.x = (a.x) / d;
	normal.y = (a.y) / d;

	return normal;
}